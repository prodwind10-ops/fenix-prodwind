/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package mozilla.components.feature.toolbar

import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.runTest
import mozilla.components.browser.state.action.ContentAction
import mozilla.components.browser.state.action.ContentAction.UpdatePermissionHighlightsStateAction
import mozilla.components.browser.state.action.ContentAction.UpdatePermissionHighlightsStateAction.NotificationChangedAction
import mozilla.components.browser.state.action.TabListAction
import mozilla.components.browser.state.action.TrackingProtectionAction
import mozilla.components.browser.state.state.BrowserState
import mozilla.components.browser.state.state.ContentState
import mozilla.components.browser.state.state.SecurityInfo
import mozilla.components.browser.state.state.TabSessionState
import mozilla.components.browser.state.state.TrackingProtectionState
import mozilla.components.browser.state.state.content.PermissionHighlightsState
import mozilla.components.browser.state.state.createCustomTab
import mozilla.components.browser.state.state.createTab
import mozilla.components.browser.state.store.BrowserStore
import mozilla.components.concept.toolbar.Toolbar
import mozilla.components.feature.toolbar.internal.URLRenderer
import mozilla.components.support.test.any
import mozilla.components.support.test.mock
import org.junit.Test
import org.mockito.Mockito.never
import org.mockito.Mockito.spy
import org.mockito.Mockito.times
import org.mockito.Mockito.verify
import org.mockito.Mockito.verifyNoMoreInteractions

class ToolbarPresenterTest {

    private val testDispatcher = StandardTestDispatcher()

    @Test
    fun `start with no custom tab id registers on store and renders selected tab`() =
        runTest(testDispatcher) {
            val toolbar: Toolbar = mock()
            val store =
                BrowserStore(
                    BrowserState(
                        tabs = listOf(createTab("https://www.mozilla.org", id = "tab1")),
                        customTabs = listOf(createCustomTab("https://www.example.org", id = "ct")),
                        selectedTabId = "tab1",
                    )
                )

            val toolbarPresenter = spy(ToolbarPresenter(toolbar, store, mainDispatcher = testDispatcher))

            toolbarPresenter.renderer = mock()

            toolbarPresenter.start()

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbarPresenter).render(any())

            verify(toolbarPresenter.renderer).post("https://www.mozilla.org")
            verify(toolbar).setSearchTerms("")
            verify(toolbar).displayProgress(0)
            verify(toolbar).siteInfo = Toolbar.SiteInfo.INSECURE
        }

    @Test
    fun `start with custom tab id registers on store and renders custom tab`() =
        runTest(testDispatcher) {
            val toolbar: Toolbar = mock()
            val store =
                BrowserStore(
                    BrowserState(
                        tabs = listOf(createTab("https://www.mozilla.org", id = "tab1")),
                        customTabs = listOf(createCustomTab("https://www.example.org", id = "ct")),
                        selectedTabId = "tab1",
                    )
                )
            val toolbarPresenter =
                spy(ToolbarPresenter(toolbar, store, customTabId = "ct", mainDispatcher = testDispatcher))
            toolbarPresenter.renderer = mock()

            toolbarPresenter.start()

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbarPresenter).render(any())

            verify(toolbarPresenter.renderer).post("https://www.example.org")
            verify(toolbar).setSearchTerms("")
            verify(toolbar).displayProgress(0)
            verify(toolbar).siteInfo = Toolbar.SiteInfo.INSECURE
        }

    @Test
    fun `SiteInfoState change updates toolbar`() =
        runTest(testDispatcher) {
            val toolbar: Toolbar = mock()
            val store =
                BrowserStore(
                    BrowserState(
                        tabs = listOf(createTab("https://www.mozilla.org", id = "tab1")),
                        customTabs = listOf(createCustomTab("https://www.example.org", id = "ct")),
                        selectedTabId = "tab1",
                    )
                )

            val toolbarPresenter = spy(ToolbarPresenter(toolbar, store, mainDispatcher = testDispatcher))
            toolbarPresenter.renderer = mock()

            toolbarPresenter.start()

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar, never()).siteInfo = Toolbar.SiteInfo.SECURE

            store.dispatch(
                ContentAction.UpdateSecurityInfoAction(
                    "tab1",
                    SecurityInfo.Secure(
                        host = "mozilla.org",
                        issuer = "Mozilla",
                    ),
                )
            )

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar).siteInfo = Toolbar.SiteInfo.SECURE
        }

    @Test
    fun `Toolbar gets cleared when all tabs are removed`() =
        runTest(testDispatcher) {
            val toolbar: Toolbar = mock()
            val store =
                BrowserStore(
                    BrowserState(
                        tabs =
                            listOf(
                                TabSessionState(
                                    id = "tab1",
                                    content =
                                        ContentState(
                                            url = "https://www.mozilla.org",
                                            securityInfo = SecurityInfo.Secure("mozilla.org", "Mozilla"),
                                            searchTerms = "Hello World",
                                            progress = 60,
                                        ),
                                )
                            ),
                        selectedTabId = "tab1",
                    )
                )

            val toolbarPresenter = spy(ToolbarPresenter(toolbar, store, mainDispatcher = testDispatcher))
            toolbarPresenter.renderer = mock()

            toolbarPresenter.start()

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbarPresenter.renderer).start()
            verify(toolbarPresenter.renderer).post("https://www.mozilla.org")
            verify(toolbar).setSearchTerms("Hello World")
            verify(toolbar).displayProgress(60)
            verify(toolbar).siteInfo = Toolbar.SiteInfo.SECURE
            verify(toolbar).siteTrackingProtection = Toolbar.SiteTrackingProtection.OFF_GLOBALLY
            verify(toolbar).highlight = Toolbar.Highlight.NONE
            verifyNoMoreInteractions(toolbarPresenter.renderer)
            verifyNoMoreInteractions(toolbar)

            store.dispatch(TabListAction.RemoveTabAction("tab1"))

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbarPresenter.renderer).post("")
            verify(toolbar).setSearchTerms("")
            verify(toolbar).displayProgress(0)
            verify(toolbar).siteInfo = Toolbar.SiteInfo.INSECURE
        }

    @Test
    fun `Search terms changes updates toolbar`() =
        runTest(testDispatcher) {
            val toolbar: Toolbar = mock()
            val store =
                BrowserStore(
                    BrowserState(
                        tabs = listOf(createTab("https://www.mozilla.org", id = "tab1")),
                        customTabs = listOf(createCustomTab("https://www.example.org", id = "ct")),
                        selectedTabId = "tab1",
                    )
                )

            val toolbarPresenter = spy(ToolbarPresenter(toolbar, store, mainDispatcher = testDispatcher))
            toolbarPresenter.renderer = mock()

            toolbarPresenter.start()

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar, never()).setSearchTerms("Hello World")

            store.dispatch(
                ContentAction.UpdateSearchTermsAction(
                    sessionId = "tab1",
                    searchTerms = "Hello World",
                )
            )

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar).setSearchTerms("Hello World")
        }

    @Test
    fun `Progress changes updates toolbar`() =
        runTest(testDispatcher) {
            val toolbar: Toolbar = mock()
            val store =
                BrowserStore(
                    BrowserState(
                        tabs = listOf(createTab("https://www.mozilla.org", id = "tab1")),
                        customTabs = listOf(createCustomTab("https://www.example.org", id = "ct")),
                        selectedTabId = "tab1",
                    )
                )

            val toolbarPresenter = spy(ToolbarPresenter(toolbar, store, mainDispatcher = testDispatcher))
            toolbarPresenter.renderer = mock()

            toolbarPresenter.start()

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar, never()).displayProgress(75)

            store.dispatch(ContentAction.UpdateProgressAction("tab1", 75))

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar).displayProgress(75)

            verify(toolbar, never()).displayProgress(90)

            store.dispatch(ContentAction.UpdateProgressAction("tab1", 90))

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar).displayProgress(90)
        }

    @Test
    fun `Toolbar does not get cleared if a background tab gets removed`() =
        runTest(testDispatcher) {
            val toolbar: Toolbar = mock()
            val store =
                BrowserStore(
                    BrowserState(
                        tabs =
                            listOf(
                                TabSessionState(
                                    id = "tab1",
                                    content =
                                        ContentState(
                                            url = "https://www.mozilla.org",
                                            securityInfo = SecurityInfo.Secure("mozilla.org", "Mozilla"),
                                            searchTerms = "Hello World",
                                            progress = 60,
                                        ),
                                ),
                                createTab(id = "tab2", url = "https://www.example.org"),
                            ),
                        selectedTabId = "tab1",
                    )
                )

            val toolbarPresenter = spy(ToolbarPresenter(toolbar, store, mainDispatcher = testDispatcher))
            toolbarPresenter.renderer = mock()

            toolbarPresenter.start()

            testDispatcher.scheduler.advanceUntilIdle()

            store.dispatch(TabListAction.RemoveTabAction("tab2"))

            verify(toolbarPresenter.renderer).start()
            verify(toolbarPresenter.renderer).post("https://www.mozilla.org")
            verify(toolbar).setSearchTerms("Hello World")
            verify(toolbar).displayProgress(60)
            verify(toolbar).siteInfo = Toolbar.SiteInfo.SECURE
            verify(toolbar).siteTrackingProtection = Toolbar.SiteTrackingProtection.OFF_GLOBALLY
            verify(toolbar).highlight = Toolbar.Highlight.NONE
            verifyNoMoreInteractions(toolbarPresenter.renderer)
            verifyNoMoreInteractions(toolbar)
        }

    @Test
    fun `Toolbar is updated when selected tab changes`() =
        runTest(testDispatcher) {
            val toolbar: Toolbar = mock()
            val store =
                BrowserStore(
                    BrowserState(
                        tabs =
                            listOf(
                                TabSessionState(
                                    id = "tab1",
                                    content =
                                        ContentState(
                                            url = "https://www.mozilla.org",
                                            securityInfo = SecurityInfo.Secure("mozilla.org", "Mozilla"),
                                            searchTerms = "Hello World",
                                            progress = 60,
                                        ),
                                ),
                                TabSessionState(
                                    id = "tab2",
                                    content =
                                        ContentState(
                                            url = "https://www.example.org",
                                            securityInfo = SecurityInfo.Insecure("example.org", "Example"),
                                            searchTerms = "Example",
                                            permissionHighlights = PermissionHighlightsState(true),
                                            progress = 90,
                                        ),
                                    trackingProtection = TrackingProtectionState(enabled = true),
                                ),
                            ),
                        selectedTabId = "tab1",
                    )
                )

            val toolbarPresenter = spy(ToolbarPresenter(toolbar, store, mainDispatcher = testDispatcher))
            toolbarPresenter.renderer = mock()

            toolbarPresenter.start()

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbarPresenter.renderer).start()
            verify(toolbarPresenter.renderer).post("https://www.mozilla.org")
            verify(toolbar).setSearchTerms("Hello World")
            verify(toolbar).displayProgress(60)
            verify(toolbar).siteInfo = Toolbar.SiteInfo.SECURE
            verify(toolbar).siteTrackingProtection = Toolbar.SiteTrackingProtection.OFF_GLOBALLY
            verify(toolbar).highlight = Toolbar.Highlight.NONE
            verifyNoMoreInteractions(toolbarPresenter.renderer)
            verifyNoMoreInteractions(toolbar)

            store.dispatch(TabListAction.SelectTabAction("tab2"))

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbarPresenter.renderer).post("https://www.example.org")
            verify(toolbar).setSearchTerms("Example")
            verify(toolbar).displayProgress(90)
            verify(toolbar).siteInfo = Toolbar.SiteInfo.INSECURE
            verify(toolbar).siteTrackingProtection = Toolbar.SiteTrackingProtection.ON_NO_TRACKERS_BLOCKED
            verify(toolbar).highlight = Toolbar.Highlight.PERMISSIONS_CHANGED
            verifyNoMoreInteractions(toolbarPresenter.renderer)
            verifyNoMoreInteractions(toolbar)
        }

    @Test
    fun `displaying different tracking protection states`() =
        runTest(testDispatcher) {
            val toolbar: Toolbar = mock()
            val store =
                BrowserStore(
                    BrowserState(
                        tabs =
                            listOf(
                                TabSessionState(
                                    id = "tab",
                                    content =
                                        ContentState(
                                            url = "https://www.mozilla.org",
                                            securityInfo = SecurityInfo.Secure("mozilla.org", "Mozilla"),
                                            searchTerms = "Hello World",
                                            progress = 60,
                                        ),
                                )
                            ),
                        selectedTabId = "tab",
                    )
                )

            val toolbarPresenter = spy(ToolbarPresenter(toolbar, store, mainDispatcher = testDispatcher))
            toolbarPresenter.renderer = mock()

            toolbarPresenter.start()

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar).siteTrackingProtection = Toolbar.SiteTrackingProtection.OFF_GLOBALLY

            store.dispatch(TrackingProtectionAction.ToggleAction("tab", true))

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar).siteTrackingProtection = Toolbar.SiteTrackingProtection.ON_NO_TRACKERS_BLOCKED

            store.dispatch(TrackingProtectionAction.TrackerBlockedAction("tab", mock()))

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar).siteTrackingProtection = Toolbar.SiteTrackingProtection.ON_TRACKERS_BLOCKED

            store.dispatch(TrackingProtectionAction.ToggleExclusionListAction("tab", true))

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar).siteTrackingProtection = Toolbar.SiteTrackingProtection.OFF_FOR_A_SITE
        }

    @Test
    fun `displaying different dot notification states`() =
        runTest(testDispatcher) {
            val toolbar: Toolbar = mock()
            val store =
                BrowserStore(
                    BrowserState(
                        tabs =
                            listOf(
                                TabSessionState(
                                    id = "tab",
                                    content =
                                        ContentState(
                                            url = "https://www.mozilla.org",
                                            securityInfo = SecurityInfo.Secure("mozilla.org", "Mozilla"),
                                            searchTerms = "Hello World",
                                            progress = 60,
                                        ),
                                )
                            ),
                        selectedTabId = "tab",
                    )
                )

            val toolbarPresenter = spy(ToolbarPresenter(toolbar, store, mainDispatcher = testDispatcher))
            toolbarPresenter.renderer = mock()

            toolbarPresenter.start()

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar).highlight = Toolbar.Highlight.NONE

            store.dispatch(NotificationChangedAction("tab", true))

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar).highlight = Toolbar.Highlight.PERMISSIONS_CHANGED

            store.dispatch(TrackingProtectionAction.ToggleExclusionListAction("tab", true))

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar, times(2)).highlight = Toolbar.Highlight.PERMISSIONS_CHANGED

            store.dispatch(UpdatePermissionHighlightsStateAction.Reset("tab"))

            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar).highlight = Toolbar.Highlight.NONE
        }

    @Test
    fun `Stopping presenter stops renderer`() =
        runTest(testDispatcher) {
            val store = BrowserStore()
            val presenter = ToolbarPresenter(mock(), store, mainDispatcher = testDispatcher)

            val renderer: URLRenderer = mock()
            presenter.renderer = renderer

            presenter.start()

            verify(renderer, never()).stop()

            presenter.stop()

            verify(renderer).stop()
        }

    @Test
    fun `Toolbar displays empty state without tabs`() =
        runTest(testDispatcher) {
            val store = BrowserStore()
            val toolbar: Toolbar = mock()
            val presenter = ToolbarPresenter(toolbar, store, mainDispatcher = testDispatcher)
            presenter.renderer = mock()

            presenter.start()

            testDispatcher.scheduler.advanceUntilIdle()

            verify(presenter.renderer).post("")
            verify(toolbar).setSearchTerms("")
            verify(toolbar).displayProgress(0)
            verify(toolbar).siteInfo = Toolbar.SiteInfo.INSECURE
            verify(toolbar).siteTrackingProtection = Toolbar.SiteTrackingProtection.OFF_GLOBALLY
            verify(toolbar).highlight = Toolbar.Highlight.NONE
        }

    @Test
    fun `GIVEN search terms should not be shown in display mode WHEN rendering a state with search terms set THEN toolbar url is the tab url`() =
        runTest(testDispatcher) {
            val url = "https://www.mozilla.org"
            val toolbar: Toolbar = mock()
            val store =
                BrowserStore(
                    BrowserState(
                        tabs = listOf(createTab(url, id = "tab1", searchTerms = "search terms")),
                        selectedTabId = "tab1",
                    )
                )
            val toolbarPresenter =
                spy(
                    ToolbarPresenter(
                        toolbar,
                        store,
                        shouldDisplaySearchTerms = false,
                        mainDispatcher = testDispatcher,
                    )
                )
            toolbarPresenter.renderer = mock()

            toolbarPresenter.start()
            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbarPresenter.renderer).post(url)
        }

    @Test
    fun `GIVEN search terms should be shown in display mode WHEN rendering a state with search terms set THEN toolbar url is set to the search terms`() =
        runTest(testDispatcher) {
            val searchTerm = "mozilla firefox"
            val toolbar: Toolbar = mock()
            val store =
                BrowserStore(
                    BrowserState(
                        tabs =
                            listOf(
                                createTab(
                                    "https://www.mozilla.org",
                                    id = "tab1",
                                    searchTerms = searchTerm,
                                )
                            ),
                        selectedTabId = "tab1",
                    )
                )
            val toolbarPresenter =
                spy(
                    ToolbarPresenter(
                        toolbar,
                        store,
                        shouldDisplaySearchTerms = true,
                        mainDispatcher = testDispatcher,
                    )
                )
            toolbarPresenter.renderer = mock()

            toolbarPresenter.start()
            testDispatcher.scheduler.advanceUntilIdle()

            verify(toolbar).url = searchTerm
        }
}
