/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package mozilla.components.feature.summarize

import mozilla.components.concept.llm.LlmProvider
import mozilla.components.feature.summarize.settings.SummarizeSettingsState
import mozilla.components.lib.state.State
import mozilla.components.ui.richtext.ir.RichDocument

/** The [State] of the [SummarizationStore] */
sealed class SummarizationState : State {
    /**
     * The feature is idle and not actively summarizing.
     *
     * @param initializedWithShake Whether the feature was first triggered via a shake gesture.
     */
    data class Inert(val initializedWithShake: Boolean) : SummarizationState()

    /** The user has requested summary but the feature is waiting for the browser page to load. */
    data object PageLoading : SummarizationState()

    /** The user must consent to shake-to-summarize before proceeding. */
    data object ShakeConsentRequired : SummarizationState()

    /** The user must consent to both the shake gesture and a model download before proceeding. */
    data object ShakeConsentWithDownloadRequired : SummarizationState()

    /** The user must download an on-device model before continuing */
    data object DownloadConsentRequired : SummarizationState()

    /** The on-device model is downloading */
    data class Downloading(val bytesToDownload: Float, val bytesDownloaded: Float) : SummarizationState() {
        val downloadProgress: Float
            get() = bytesToDownload / bytesToDownload
    }

    /**
     * We're waiting for an initial response from the [mozilla.components.concept.llm.Llm].
     *
     * @param info the information for the current [mozilla.components.concept.llm.Llm]
     */
    data class Loading(val info: LlmProvider.Info) : SummarizationState()

    /**
     * Summarization is in progress. The LLM has started to respond, but it has not finished yet.
     *
     * @param info metadata about the LLM that generated the summary
     * @param document the document we've generated so far.
     */
    data class Summarizing(
        val info: LlmProvider.Info,
        val document: RichDocument = RichDocument(listOf()),
    ) : SummarizationState()

    /**
     * Summarization completed successfully.
     *
     * @param info metadata about the LLM that generated the summary
     * @param document The generated document.
     * @param feedback The rating the user gave the summary. The user can change the rating for as long as the summary
     *   is on screen.
     */
    data class Summarized(
        val info: LlmProvider.Info,
        val document: RichDocument = RichDocument(listOf()),
        val feedback: SummaryFeedback = SummaryFeedback.NOT_PROVIDED,
    ) : SummarizationState()

    /**
     * An error occurred during the summarization lifecycle.
     *
     * @param error The [SummarizationError] describing what went wrong.
     */
    data class Error(val error: SummarizationError) : SummarizationState()

    /**
     * The user is viewing the summarization settings.
     *
     * @param info metadata about the LLM that generated the summary
     * @param document The document to return to when navigating back.
     * @param settingsState The state of the embedded summarize settings.
     * @param feedback The rating to restore when navigating back to the summary.
     */
    data class Settings(
        val info: LlmProvider.Info,
        val document: RichDocument,
        val settingsState: SummarizeSettingsState,
        val feedback: SummaryFeedback = SummaryFeedback.NOT_PROVIDED,
    ) : SummarizationState()

    /** User is finished with the Summarization Flow */
    sealed class Finished : SummarizationState() {
        /** User finished by canceling the flow. */
        data object Cancelled : Finished()

        /** User finished by dismissing the error screen. */
        data object ErrorDismissed : Finished()

        /** User finished by navigating to the Mozilla account sign-in flow. */
        data object NavigatedToSignIn : Finished()
    }

    /** User clicked Learn More in the shake consent screen. */
    data object LearnMoreAboutShakeConsent : SummarizationState()

    /** User clicked Learn More to explore cloud-supported features. */
    data object LearnMoreAboutCloudSupportedFeatures : SummarizationState()

    /** The user must sign in before summarization can proceed. */
    data object SignInRequired : SummarizationState()

    companion object {
        val initial: SummarizationState
            get() = Inert(false)
    }
}

/** Describes the possible failure modes of the summarization feature. */
sealed class SummarizationError {
    /** The model download did not complete successfully. */
    data object DownloadFailed : SummarizationError()

    /** The summarization model failed to produce a result. */
    data class SummarizationFailed(val exception: Throwable) : SummarizationError()
}

/** The rating a user can give a generated summary via the feedback control. */
enum class SummaryFeedback {
    /** The summary cannot be rated yet, so the feedback control is not shown. */
    NOT_READY,

    /** The summary can be rated but the user has not done so. */
    NOT_PROVIDED,

    /** The user found the summary helpful. */
    GOOD,

    /** The user found the summary unhelpful. */
    BAD,
}

val SummarizationState.isLoading
    get() = this is SummarizationState.Loading
val SummarizationState.isPageLoading
    get() = this is SummarizationState.PageLoading
val SummarizationState.isSummarizing
    get() = this is SummarizationState.Summarizing
val SummarizationState.isSummarized
    get() = this is SummarizationState.Summarized
