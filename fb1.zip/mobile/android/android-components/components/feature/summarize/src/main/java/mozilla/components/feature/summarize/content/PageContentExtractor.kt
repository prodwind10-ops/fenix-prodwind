/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package mozilla.components.feature.summarize.content

/** An interface to conform to do deliver page content for summarization. */
fun interface PageContentExtractor {
    /** Retrieve the page content. */
    suspend fun getPageContent(options: Options): Result<String>

    /** Options defining how the content should be extracted. */
    data class Options(val shouldUseReaderModeContent: Boolean)
}
