/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.tabstray.controller

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.annotation.ColorInt
import androidx.annotation.VisibleForTesting
import androidx.navigation.NavController
import java.util.concurrent.TimeUnit
import kotlin.coroutines.CoroutineContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import mozilla.components.browser.state.action.DebugAction
import mozilla.components.browser.state.action.LastAccessAction
import mozilla.components.browser.state.selector.findTab
import mozilla.components.browser.state.selector.normalTabs
import mozilla.components.browser.state.selector.privateTabs
import mozilla.components.browser.state.selector.selectedTab
import mozilla.components.browser.state.state.BrowserState
import mozilla.components.browser.state.store.BrowserStore
import mozilla.components.browser.storage.sync.Tab
import mozilla.components.concept.base.profiler.Profiler
import mozilla.components.concept.engine.prompt.ShareData
import mozilla.components.concept.engine.utils.ABOUT_HOME_URL
import mozilla.components.feature.accounts.push.CloseTabsUseCases
import mozilla.components.feature.downloads.ui.DownloadCancelDialogFragment
import mozilla.components.feature.session.SessionUseCases
import mozilla.components.feature.tabs.TabsUseCases
import mozilla.components.lib.state.DelicateAction
import mozilla.components.service.fxa.manager.FxaAccountManager
import mozilla.components.support.base.log.logger.Logger
import mozilla.telemetry.glean.private.NoExtras
import org.mozilla.fenix.GleanMetrics.Collections
import org.mozilla.fenix.GleanMetrics.Events
import org.mozilla.fenix.GleanMetrics.TabsTray
import org.mozilla.fenix.GleanMetrics.TrackingProtection
import org.mozilla.fenix.R
import org.mozilla.fenix.browser.browsingmode.BrowsingMode
import org.mozilla.fenix.browser.browsingmode.BrowsingModeManager
import org.mozilla.fenix.collections.CollectionsDialog
import org.mozilla.fenix.collections.show
import org.mozilla.fenix.components.AppStore
import org.mozilla.fenix.components.TabCollectionStorage
import org.mozilla.fenix.components.accounts.FenixFxAEntryPoint
import org.mozilla.fenix.components.appstate.AppAction
import org.mozilla.fenix.components.bookmarks.BookmarksUseCase
import org.mozilla.fenix.components.share.ShareSheetChooserAction
import org.mozilla.fenix.components.share.ShareSource
import org.mozilla.fenix.components.usecases.FenixBrowserUseCases
import org.mozilla.fenix.components.usecases.ShareUseCases
import org.mozilla.fenix.ext.DEFAULT_ACTIVE_DAYS
import org.mozilla.fenix.ext.nav
import org.mozilla.fenix.ext.openToBrowser
import org.mozilla.fenix.ext.potentialInactiveTabs
import org.mozilla.fenix.ext.removeAllActiveUnlockedNormalTabs
import org.mozilla.fenix.ext.removeAllUnlockedNormalTabs
import org.mozilla.fenix.ext.removeAllUnlockedPrivateTabs
import org.mozilla.fenix.home.HomeScreenViewModel.Companion.ALL_ACTIVE_NORMAL_TABS
import org.mozilla.fenix.home.HomeScreenViewModel.Companion.ALL_NORMAL_TABS
import org.mozilla.fenix.home.HomeScreenViewModel.Companion.ALL_PRIVATE_TABS
import org.mozilla.fenix.share.ShareFragment
import org.mozilla.fenix.tabstray.SyncedTabsController
import org.mozilla.fenix.tabstray.browser.InactiveTabsController
import org.mozilla.fenix.tabstray.browser.TabsTrayFabController
import org.mozilla.fenix.shortcut.LockedTabShortcut
import org.mozilla.fenix.tabstray.data.TabsTrayItem
import org.mozilla.fenix.tabstray.data.toTabList
import org.mozilla.fenix.tabstray.ext.isActiveDownload
import org.mozilla.fenix.tabstray.ext.isSelect
import org.mozilla.fenix.tabstray.redux.action.TabsTrayAction
import org.mozilla.fenix.tabstray.redux.state.Page
import org.mozilla.fenix.tabstray.redux.state.TabsTrayState
import org.mozilla.fenix.tabstray.redux.store.TabsTrayStore
import org.mozilla.fenix.tabstray.ui.TabManagementFragmentDirections
import org.mozilla.fenix.utils.Settings

internal const val INACTIVE_TABS_FEATURE_NAME = "Inactive tabs"

@VisibleForTesting internal const val TABS_TRAY_TELEMETRY_SOURCE = "tabs_tray"

/** Controller for handling any actions in the tab manager. */
interface TabManagerController : SyncedTabsController, InactiveTabsController, TabsTrayFabController {

    /**
     * Set the current visible tab page to the provided [page].
     *
     * @param page The page on the tab manager to focus.
     */
    fun handleTabPageClicked(page: Page)

    /** Navigate from the Tab Manager to Browser. */
    fun handleNavigateToBrowser()

    /** Navigates from the tab manager to the homepage. */
    fun handleNavigateToHome()

    /**
     * Deletes the [TabsTrayItem] with the specified [tabId] or calls [DownloadCancelDialogFragment] if user tries to
     * close the last private tab while private downloads are active. This method has no effect if the tab does not
     * exist.
     *
     * @param tab The [TabsTrayItem.Tab] to be removed from the Tab Manager.
     * @param source app feature from which the tab with [tabId] was closed.
     */
    fun handleTabDeletion(tab: TabsTrayItem.Tab, source: String? = null)

    /**
     * Deletes the [TabsTrayItem] with the specified [tabId]
     *
     * @param tabId The id of the [TabsTrayItem] to be removed from the Tab Manager.
     * @param source app feature from which the tab with [tabId] was closed.
     */
    fun handleDeletePrivateTabWarningAccepted(tabId: String, source: String? = null)

    /** Deletes the current state of selected tabs, offering an undo option. */
    fun handleDeleteSelectedTabsClicked()

    /** Bookmarks the current set of selected tabs. */
    fun handleBookmarkSelectedTabsClicked()

    /** Saves the current set of selected tabs to a collection. */
    fun handleAddSelectedTabsToCollectionClicked()

    /** Shares the current set of selected tabs. */
    fun handleShareSelectedTabsClicked()

    /**
     * Shares the tabs in the given tab group.
     *
     * @param group The tab group to share.
     * @param dotColor The ARGB color of the group's theme dot, forwarded for the share preview.
     * @param thumbnailUri Optional cached thumbnail image shown in the system share sheet preview.
     */
    fun handleShareTabGroupClicked(
        group: TabsTrayItem.TabGroup,
        @ColorInt dotColor: Int,
        thumbnailUri: Uri?,
    )

    /** Navigate from the Tab Manager to Recently Closed section in the History fragment. */
    fun handleNavigateToRecentlyClosed()

    /**
     * Marks all selected tabs' last access timestamp to be 15 days or [numDays]; enough time to have a tab considered
     * as inactive.
     *
     * ⚠️ DO NOT USE THIS OUTSIDE OF DEBUGGING/TESTING.
     *
     * @param numDays The number of days to mark a tab's last access date.
     */
    fun handleForceSelectedTabsAsInactiveClicked(numDays: Long = DEFAULT_ACTIVE_DAYS + 1)

    /**
     * Adds the provided tab to the current selection of tabs.
     *
     * @param tab [TabsTrayItem.Tab] to be selected.
     * @param source App feature from which the tab was selected.
     */
    fun handleTabSelected(
        tab: TabsTrayItem.Tab,
        source: String?,
    )

    /** Handle the completion of the TabTray transition animation. */
    fun handleNavigationRequested()

    /**
     * Exits multi select mode when the back button was pressed.
     *
     * @return true if the button press was consumed.
     */
    fun handleBackPressed(): Boolean

    /** Navigates to the sign into Sync flow */
    fun handleSignInClicked()

    /** Called when clicking the account settings button. */
    fun onAccountSettingsClicked()

    /** Called when clicking the tab settings button. */
    fun onTabSettingsClicked()

    /** Called when clicking the close all tabs button. */
    fun onCloseAllTabsClicked(private: Boolean)

    /**
     * Called when clicking the refresh all tabs button. Refreshes every tab on the currently selected page
     * (normal or private tabs); the other page's tabs are left untouched.
     */
    fun onRefreshAllTabsClicked()

    /**
     * Called when clicking the return locked tabs to their root pages menu item. Navigates every locked tab on the
     * currently selected page (normal or private tabs) back to its root URL, the page it was on when it was locked.
     * Locked tabs already on their root page, unlocked tabs and the other page's tabs are left untouched.
     */
    fun onReturnLockedTabsToRootClicked()

    /**
     * Called when choosing to return the selected locked tabs to their root pages. Leaves select mode afterwards.
     */
    fun onReturnSelectedTabsToRootClicked()

    /**
     * Called when choosing to add a Home screen shortcut that opens the given locked [tab] instead of creating a new
     * one. Leaves select mode afterwards.
     *
     * @param tab The locked tab to create the shortcut for.
     */
    fun onAddTabToHomeScreenClicked(tab: TabsTrayItem.Tab)

    /** Called when cancelling private downloads confirmed. */
    fun onCloseAllPrivateTabsWarningConfirmed(private: Boolean)

    /** Called when opening the recently closed tabs menu button. */
    fun onOpenRecentlyClosedClicked()

    /** Called when the trackers blocked pill is tapped. */
    fun onPrivacyReportTapped()
}

/**
 * Default implementation of [TabManagerController].
 *
 * @param accountManager [FxaAccountManager] used to determine signed in status.
 * @param context [Context] used for showing dialogs.
 * @param appStore [AppStore] used to dispatch any [AppAction].
 * @param tabsTrayStore [TabsTrayStore] used to read/update the [TabsTrayState].
 * @param browserStore [BrowserStore] used to read/update the current [BrowserState].
 * @param settings [Settings] used to update any user preferences.
 * @param browsingModeManager [BrowsingModeManager] used to read/update the current [BrowsingMode].
 * @param navController [NavController] used to navigate away from the tab manager.
 * @param navigateToHomeAndDeleteSession Lambda used to return to the Homescreen and delete the current session.
 * @param profiler [Profiler] used to add profiler markers.
 * @param tabsUseCases Use case wrapper for interacting with tabs.
 * @param fenixBrowserUseCases [FenixBrowserUseCases] used for adding new homepage tabs.
 * @param shareUseCases [ShareUseCases] for sharing content via the system share sheet or the in-app [ShareFragment].
 * @param closeSyncedTabsUseCases Use cases for closing synced tabs.
 * @param addBookmarkUseCase Use case for adding a new bookmark; resolves the parent folder via the shared
 *   [LastSavedFolderCache] so the tab manager's bulk save lands in the same folder as single-bookmark saves from the
 *   toolbar and menu.
 * @param ioDispatcher [CoroutineContext] used for storage operations.
 * @param mainDispatcher [CoroutineContext] used for UI operations.
 * @param collectionStorage Storage layer for interacting with collections.
 * @param showUndoSnackbarForTab Lambda used to display an undo snackbar when a normal or private tab is closed.
 * @param showUndoSnackbarForInactiveTab Lambda used to display an undo snackbar when an inactive tab is closed.
 * @param showUndoSnackbarForSyncedTab Lambda used to display an undo snackbar when a synced tab is closed.
 * @param showUndoSnackbarForMultipleTabs Lambda used to display an undo snackbar when multiple normal or private tabs
 *   are closed.
 * @property showCancelledDownloadWarning Lambda used to display a cancelled download warning.
 * @param showBookmarkSnackbar Lambda used to display a snackbar upon saving tabs as bookmarks.
 * @param showCollectionSnackbar Lambda used to display a snackbar upon successfully saving tabs to a collection.
 * @param currentTimeMillis provider for the current time in milliseconds, injectable for testing.
 */
@Suppress("TooManyFunctions", "LongParameterList")
class DefaultTabManagerController(
    private val accountManager: FxaAccountManager,
    private val context: Context,
    private val appStore: AppStore,
    private val tabsTrayStore: TabsTrayStore,
    private val browserStore: BrowserStore,
    private val settings: Settings,
    private val browsingModeManager: BrowsingModeManager,
    private val navController: NavController,
    private val navigateToHomeAndDeleteSession: (String) -> Unit,
    private val profiler: Profiler?,
    private val tabsUseCases: TabsUseCases,
    private val sessionUseCases: SessionUseCases,
    private val fenixBrowserUseCases: FenixBrowserUseCases,
    private val shareUseCases: ShareUseCases,
    private val closeSyncedTabsUseCases: CloseTabsUseCases,
    private val addBookmarkUseCase: BookmarksUseCase.AddBookmarksUseCase,
    private val ioDispatcher: CoroutineContext = Dispatchers.IO,
    private val mainDispatcher: CoroutineContext = Dispatchers.Main,
    private val collectionStorage: TabCollectionStorage,
    private val showUndoSnackbarForTab: (Boolean) -> Unit,
    private val showUndoSnackbarForInactiveTab: (Int) -> Unit,
    private val showUndoSnackbarForSyncedTab: (CloseTabsUseCases.UndoableOperation) -> Unit,
    private val showUndoSnackbarForMultipleTabs: (isPrivate: Boolean, count: Int) -> Unit,
    internal val showCancelledDownloadWarning: (downloadCount: Int, tabId: String?, source: String?) -> Unit,
    private val showBookmarkSnackbar: (tabSize: Int, parentFolderTitle: String?) -> Unit,
    private val showCollectionSnackbar:
        (
            tabSize: Int,
            isNewCollection: Boolean,
        ) -> Unit,
    private val currentTimeMillis: () -> Long = { System.currentTimeMillis() },
) : TabManagerController {

    override fun handleNormalTabsFabClick() {
        openNewTab(isPrivate = false)
    }

    override fun handlePrivateTabsFabClick() {
        openNewTab(isPrivate = true)
    }

    override fun handleSyncedTabsFabClick() {
        if (!tabsTrayStore.state.sync.isSyncing) {
            tabsTrayStore.dispatch(TabsTrayAction.SyncNow)
        }
    }

    /**
     * Opens a new tab.
     *
     * @param isPrivate [Boolean] indicating whether the new tab is private.
     */
    private fun openNewTab(isPrivate: Boolean) {
        val startTime = profiler?.getProfilerTime()
        browsingModeManager.mode = BrowsingMode.fromBoolean(isPrivate)

        if (settings.enableHomepageAsNewTab) {
            fenixBrowserUseCases.addNewHomepageTab(private = isPrivate)
            handleNavigateToHome()
        } else {
            navController.popBackStack()
            navController.navigate(
                TabManagementFragmentDirections.actionGlobalHome(
                    focusOnAddressBar = !settings.enableHomepageTrendingRecentSearch
                )
            )
        }

        TabsTray.closed.record(NoExtras())
        profiler?.addMarker(
            "DefaultTabManagerController.onNewTabTapped",
            startTime,
        )
        sendNewTabEvent(isPrivate)
    }

    override fun handleTabPageClicked(page: Page) {
        if (page != tabsTrayStore.state.selectedPage) {
            when (page) {
                Page.NormalTabs -> TabsTray.normalModeTapped.record(NoExtras())
                Page.PrivateTabs -> TabsTray.privateModeTapped.record(NoExtras())
                Page.TabGroups -> TabsTray.tabGroupModeTapped.record(NoExtras())
                Page.SyncedTabs -> TabsTray.syncedModeTapped.record(NoExtras())
            }
        }
        tabsTrayStore.dispatch(TabsTrayAction.PageSelected(page))
    }

    override fun handleNavigateToBrowser() {
        if (!navController.popBackStack(R.id.browserFragment, false)) {
            navController.navigate(R.id.browserFragment)
        }
    }

    override fun handleNavigateToHome() {
        if (!navController.popBackStack(R.id.homeFragment, false)) {
            navController.navigate(TabManagementFragmentDirections.actionGlobalHome())
        }
    }

    override fun handleTabDeletion(tab: TabsTrayItem.Tab, source: String?) {
        deleteTab(tab, source, isConfirmed = false)
    }

    override fun handleDeletePrivateTabWarningAccepted(tabId: String, source: String?) {
        val privateTab = tabsTrayStore.state.privateBrowsing.tabs.find { it.id == tabId } as? TabsTrayItem.Tab

        if (privateTab == null) {
            Logger.error("handleDeletePrivateTabWarningAccepted: Failed to find private tab with ID $tabId")
            return
        }
        deleteTab(privateTab, source, isConfirmed = true)
    }

    private fun deleteTab(tab: TabsTrayItem.Tab, source: String?, isConfirmed: Boolean) {
        if (isTabProtectedFromClosure(tab)) {
            return
        }

        val isPrivate = tab.private
        val isNormal = !isPrivate

        val tabsRemaining = willTabsRemainAfterDeletion(isPrivate = isPrivate, closingTabIds = setOf(tab.id))

        val isCurrentTab = tabsTrayStore.state.selectedTabId == tab.id

        if (tabsRemaining || !isCurrentTab) {
            val excludedFallbackTabIds = if (isNormal) getExcludedFallbackNormalTabIds() else emptySet()

            tabsUseCases.removeTab(excludedFallbackTabIds = excludedFallbackTabIds, tabId = tab.id)
            showUndoSnackbarForTab(isPrivate)

            TabsTray.closedExistingTab.record(TabsTray.ClosedExistingTabExtra(source ?: "unknown"))
            tabsTrayStore.dispatch(TabsTrayAction.ExitSelectMode)
        } else {
            handleNoTabsRemainingDeleteTab(
                isPrivate = isPrivate,
                tab = tab,
                source = source,
                isConfirmed = isConfirmed,
            )
        }
    }

    private fun handleNoTabsRemainingDeleteTab(
        isPrivate: Boolean,
        tab: TabsTrayItem.Tab,
        source: String?,
        isConfirmed: Boolean,
    ) {
        val browserState = browserStore.state
        val privateDownloads =
            browserState.downloads.filter { map ->
                map.value.private && map.value.isActiveDownload()
            }
        if (!isConfirmed && privateDownloads.isNotEmpty()) {
            showCancelledDownloadWarning(privateDownloads.size, tab.id, source)
            return
        } else if (settings.enableHomepageAsNewTab) {
            val excludedFallbackTabIds = if (isPrivate) emptySet() else getExcludedFallbackNormalTabIds()
            tabsUseCases.removeTab(
                tabId = tab.id,
                excludedFallbackTabIds = excludedFallbackTabIds,
            )
            showUndoSnackbarForTab(isPrivate)
        } else {
            dismissTabManagerAndNavigateHome(tab.id)
        }

        TabsTray.closedExistingTab.record(TabsTray.ClosedExistingTabExtra(source ?: "unknown"))
        tabsTrayStore.dispatch(TabsTrayAction.ExitSelectMode)
    }

    /**
     * Calculates the IDs of normal tabs that should be protected from being selected after other tabs are deleted. This
     * includes all inactive tabs and tabs inside open (visible) tab groups.
     */
    private fun getExcludedFallbackNormalTabIds(): Set<String> {
        val state = tabsTrayStore.state

        val inactiveTabIds = state.inactiveTabs.tabs.map { it.id }

        val openGroupTabIds = state.tabGroupState.groups.filterNot { it.closed }.toTabList().map { it.id }

        return (inactiveTabIds + openGroupTabIds).toSet()
    }

    /**
     * Returns true if [tab] is locked, or belongs to a tab group that is locked, and should therefore be protected
     * from closure by any "close tab", "close selected tabs", or "close all tabs" action.
     */
    private fun isTabProtectedFromClosure(tab: TabsTrayItem.Tab): Boolean {
        if (tab.locked) {
            return true
        }

        val state = tabsTrayStore.state
        return state.tabGroupState.groups.any { it.locked && it.tabs.any { groupTab -> groupTab.id == tab.id } }
    }

    /**
     * Calculates the IDs of all normal tabs that are protected from closure, either because the tab itself is
     * locked or because it belongs to a locked tab group. Used to exclude those tabs from a "close all normal
     * tabs" or "close selected tabs" action.
     */
    private fun getLockedNormalTabIds(): Set<String> {
        val state = tabsTrayStore.state

        val lockedStandaloneTabIds =
            state.normalTabsState.items.toTabList().filter { it.locked }.map { it.id }

        val lockedGroupTabIds =
            state.tabGroupState.groups.filter { it.locked }.flatMap { group -> group.tabs.map { it.id } }

        return (lockedStandaloneTabIds + lockedGroupTabIds).toSet()
    }

    /**
     * Calculates the IDs of all private tabs that are locked and therefore protected from closure. Private tabs
     * cannot belong to a tab group, so only standalone tab locking applies here.
     */
    private fun getLockedPrivateTabIds(): Set<String> =
        tabsTrayStore.state.privateBrowsing.tabs.filterIsInstance<TabsTrayItem.Tab>()
            .filter { it.locked }
            .map { it.id }
            .toSet()

    /**
     * Determines if there will be any tabs left to display after a deletion. Shared between single and multiple tab
     * deletions to ensure routing logic stays in sync. When closing all normal tabs and at least 1 tab group is open,
     * this will always return true.
     *
     * @param isPrivate Indicates whether the tabs being deleted is private.
     * @param closingTabIds The set of tab IDs of tabs that are to be deleted.
     */
    private fun willTabsRemainAfterDeletion(
        isPrivate: Boolean,
        closingTabIds: Set<String>,
    ): Boolean {
        val activeTabs =
            if (isPrivate) {
                tabsTrayStore.state.privateBrowsing.tabs
            } else {
                tabsTrayStore.state.normalTabsState.items.toTabList()
            }

        val closingAllActiveTabs = closingTabIds.containsAll(activeTabs.map { it.id })

        return !closingAllActiveTabs
    }

    override fun handleDeleteSelectedTabsClicked() {
        val tabs = tabsTrayStore.state.mode.selectedTabs

        TabsTray.closeSelectedTabs.record(TabsTray.CloseSelectedTabsExtra(tabCount = tabs.size))

        deleteMultipleTabs(tabs)

        tabsTrayStore.dispatch(TabsTrayAction.ExitSelectMode)
    }

    /** Helper function to delete multiple tabs and offer an undo option. */
    @VisibleForTesting
    internal fun deleteMultipleTabs(tabs: Collection<TabsTrayItem.Tab>) {
        val closableTabs = tabs.filterNot { isTabProtectedFromClosure(it) }

        if (closableTabs.isEmpty()) {
            return
        }

        val isPrivate = closableTabs.any { it.private }
        val isNormal = !isPrivate

        val closingTabIds = closableTabs.map { it.id }.toSet()

        if (willTabsRemainAfterDeletion(isPrivate = isPrivate, closingTabIds = closingTabIds)) {
            val excludedFallbackTabIds = if (isNormal) getExcludedFallbackNormalTabIds() else emptySet()

            tabsUseCases.removeTabs(excludedFallbackTabIds = excludedFallbackTabIds, ids = closableTabs.map { it.id })
            showUndoSnackbarForMultipleTabs(isPrivate, closableTabs.size)
        } else {
            handleRemoveAllTabs(
                isHomepageAsNewTabEnabled = settings.enableHomepageAsNewTab,
                sessionId = if (isPrivate) ALL_PRIVATE_TABS else ALL_ACTIVE_NORMAL_TABS,
            )
        }
    }

    override fun handleNavigateToRecentlyClosed() {
        navController.navigate(R.id.recentlyClosedFragment)
    }

    @OptIn(DelicateAction::class)
    override fun handleForceSelectedTabsAsInactiveClicked(numDays: Long) {
        val tabs = tabsTrayStore.state.mode.selectedTabs
        val currentTabId = browserStore.state.selectedTabId
        tabs
            .filterNot { it.id == currentTabId }
            .forEach { tab ->
                val daysSince = currentTimeMillis() - TimeUnit.DAYS.toMillis(numDays)
                browserStore.apply {
                    dispatch(LastAccessAction.UpdateLastAccessAction(tab.id, daysSince))
                    dispatch(DebugAction.UpdateCreatedAtAction(tab.id, daysSince))
                }
            }

        tabsTrayStore.dispatch(TabsTrayAction.ExitSelectMode)
    }

    override fun handleBookmarkSelectedTabsClicked() {
        val tabs = tabsTrayStore.state.mode.selectedTabs

        tabsTrayStore.dispatch(TabsTrayAction.BookmarkSelectedTabs(tabCount = tabs.size))

        // We don't combine the context with lifecycleScope so that our jobs are not cancelled
        // if we leave the fragment, i.e. we still want the bookmarks to be added if the
        // tab manager closes before the job is done.
        CoroutineScope(ioDispatcher).launch {
            Result.runCatching {
                    val results = tabs.map { tab ->
                        addBookmarkUseCase(url = tab.url, title = tab.title)
                    }
                    val parentNode = results.firstOrNull()?.parentNode
                    withContext(mainDispatcher) {
                        showBookmarkSnackbar(tabs.size, parentNode?.title)
                    }
                }
                .getOrElse {
                    // silently fail
                }
        }

        tabsTrayStore.dispatch(TabsTrayAction.ExitSelectMode)
    }

    override fun handleAddSelectedTabsToCollectionClicked() {
        val tabs = tabsTrayStore.state.mode.selectedTabs

        TabsTray.selectedTabsToCollection.record(TabsTray.SelectedTabsToCollectionExtra(tabCount = tabs.size))
        TabsTray.saveToCollection.record(NoExtras())

        tabsTrayStore.dispatch(TabsTrayAction.ExitSelectMode)

        showCollectionsDialog(tabs)
    }

    @VisibleForTesting
    internal fun showCollectionsDialog(tabs: Collection<TabsTrayItem.Tab>) {
        val tabIds = tabs.map { it.id }.toSet()
        val transformedTabs = browserStore.state.tabs.filter { it.id in tabIds }
        CollectionsDialog(
                storage = collectionStorage,
                sessionList = transformedTabs,
                onPositiveButtonClick = { id, isNewCollection ->

                    // If collection is null, a new one was created.
                    if (isNewCollection) {
                        Collections.saved.record(
                            Collections.SavedExtra(
                                tabsTrayStore.state.normalTabsState.tabCount.toString(),
                                tabs.size.toString(),
                            )
                        )
                    } else {
                        Collections.tabsAdded.record(
                            Collections.TabsAddedExtra(
                                tabsTrayStore.state.normalTabsState.tabCount.toString(),
                                tabs.size.toString(),
                            )
                        )
                    }
                    id?.apply {
                        showCollectionSnackbar(tabs.size, isNewCollection)
                    }
                },
                onNegativeButtonClick = {},
            )
            .show(context)
    }

    override fun handleShareSelectedTabsClicked() {
        val tabs = tabsTrayStore.state.mode.selectedTabs

        TabsTray.shareSelectedTabs.record(TabsTray.ShareSelectedTabsExtra(tabCount = tabs.size))

        val data = tabs.map {
            ShareData(url = it.url, title = it.title, private = it.private)
        }

        shareUseCases.shareItems(
            items = data,
            source = ShareSource.TABS_TRAY,
            isPrivate = tabs.any { it.private },
            chooserActions = ShareSheetChooserAction.tabChooserActions,
            navigateToShareFragment = {
                navController.navigate(
                    TabManagementFragmentDirections.actionGlobalShareFragment(data = data.toTypedArray())
                )
            },
        )
    }

    override fun handleShareTabGroupClicked(
        group: TabsTrayItem.TabGroup,
        @ColorInt dotColor: Int,
        thumbnailUri: Uri?,
    ) {
        TabsTray.shareTabGroup.record(TabsTray.ShareTabGroupExtra(tabCount = group.tabs.size))

        val data =
            group.tabs.map {
                ShareData(url = it.url, title = it.title, private = it.private)
            }

        shareUseCases.shareItems(
            items = data,
            source = ShareSource.TABS_TRAY,
            isPrivate = group.tabs.any { it.private },
            subject = group.title,
            chooserActions = ShareSheetChooserAction.tabChooserActions,
            thumbnailUri = thumbnailUri,
            navigateToShareFragment = {
                navController.navigate(
                    TabManagementFragmentDirections.actionGlobalShareFragment(
                        data = data.toTypedArray(),
                        shareGroupTitle = group.title,
                        shareGroupColor = dotColor,
                    )
                )
            },
        )
    }

    @VisibleForTesting
    internal fun sendNewTabEvent(isPrivateModeSelected: Boolean) {
        if (isPrivateModeSelected) {
            TabsTray.newPrivateTabTapped.record(NoExtras())
        } else {
            TabsTray.newTabTapped.record(NoExtras())
        }
    }

    /** Navigate to home and delegate the session deletion to the Home Screen. */
    @VisibleForTesting
    internal fun dismissTabManagerAndNavigateHome(sessionId: String) {
        navigateToHomeAndDeleteSession(sessionId)
    }

    override fun handleSyncedTabClicked(tab: Tab) {
        Events.syncedTabOpened.record(NoExtras())

        navController.openToBrowser()

        fenixBrowserUseCases.loadUrlOrSearch(
            searchTermOrURL = tab.active().url,
            newTab = true,
        )
    }

    override fun handleSyncedTabClosed(deviceId: String, tab: Tab) {
        CoroutineScope(ioDispatcher).launch {
            val operation = closeSyncedTabsUseCases.close(deviceId, tab.active().url)
            withContext(mainDispatcher) {
                showUndoSnackbarForSyncedTab(operation)
            }
        }
    }

    override fun handleTabSelected(tab: TabsTrayItem.Tab, source: String?) {
        val selected = tabsTrayStore.state.mode.selectedTabs
        when {
            selected.isEmpty() && tabsTrayStore.state.mode.isSelect().not() -> {
                TabsTray.openedExistingTab.record(TabsTray.OpenedExistingTabExtra(source ?: "unknown"))
                tabsUseCases.selectTab(tab.id)
                val mode = BrowsingMode.fromBoolean(tab.private)
                browsingModeManager.mode = mode

                handleNavigationRequested()
            }

            tab in selected -> {
                tabsTrayStore.dispatch(TabsTrayAction.RemoveSelectTab(tab))
            }

            source != INACTIVE_TABS_FEATURE_NAME -> {
                tabsTrayStore.dispatch(TabsTrayAction.AddSelectTab(tab))
            }
        }
    }

    private fun selectedTabisHome(): Boolean {
        return browserStore.state.selectedTab?.content?.url == ABOUT_HOME_URL
    }

    override fun handleNavigationRequested() {
        if (selectedTabisHome()) {
            handleNavigateToHome()
        } else {
            handleNavigateToBrowser()
        }
    }

    override fun handleBackPressed(): Boolean {
        if (tabsTrayStore.state.mode is TabsTrayState.Mode.Select) {
            tabsTrayStore.dispatch(TabsTrayAction.ExitSelectMode)
            return true
        }
        return false
    }

    override fun handleInactiveTabClicked(tab: TabsTrayItem.Tab) {
        TabsTray.openInactiveTab.add()
        handleTabSelected(tab, INACTIVE_TABS_FEATURE_NAME)
    }

    override fun handleCloseInactiveTabClicked(tab: TabsTrayItem.Tab) {
        TabsTray.closeInactiveTab.add()
        handleTabDeletion(tab, INACTIVE_TABS_FEATURE_NAME)
    }

    override fun handleInactiveTabsHeaderClicked(expanded: Boolean) {
        appStore.dispatch(AppAction.UpdateInactiveExpanded(expanded))

        when (expanded) {
            true -> TabsTray.inactiveTabsExpanded.record(NoExtras())
            false -> TabsTray.inactiveTabsCollapsed.record(NoExtras())
        }
    }

    override fun handleInactiveTabsAutoCloseDialogDismiss() {
        markDialogAsShown()
        TabsTray.autoCloseDimissed.record(NoExtras())
    }

    override fun handleEnableInactiveTabsAutoCloseClicked() {
        markDialogAsShown()
        settings.closeTabsAfterOneMonth = true
        settings.closeTabsAfterOneWeek = false
        settings.closeTabsAfterOneDay = false
        settings.manuallyCloseTabs = false
        TabsTray.autoCloseTurnOnClicked.record(NoExtras())
    }

    override fun handleDeleteAllInactiveTabsClicked() {
        val numTabs: Int
        TabsTray.closeAllInactiveTabs.record(NoExtras())
        val lockedTabIds = getLockedNormalTabIds()
        browserStore.state.potentialInactiveTabs
            .map { it.id }
            .filterNot { it in lockedTabIds }
            .let {
                tabsUseCases.removeTabs(it, excludedFallbackTabIds = lockedTabIds)
                numTabs = it.size
            }
        showUndoSnackbarForInactiveTab(numTabs)
    }

    override fun handleSignInClicked() {
        navController.navigate(
            TabManagementFragmentDirections.actionGlobalTurnOnSync(entrypoint = FenixFxAEntryPoint.SyncedTabsMenu)
        )
    }

    override fun onAccountSettingsClicked() {
        val isSignedIn = accountManager.authenticatedAccount() != null

        val direction =
            if (isSignedIn) {
                TabManagementFragmentDirections.actionGlobalAccountSettingsFragment()
            } else {
                TabManagementFragmentDirections.actionGlobalTurnOnSync(
                    entrypoint = FenixFxAEntryPoint.NavigationInteraction
                )
            }
        navController.navigate(direction)
    }

    override fun onTabSettingsClicked() {
        navController.navigate(TabManagementFragmentDirections.actionGlobalTabSettingsFragment())
    }

    override fun onCloseAllTabsClicked(private: Boolean) {
        closeAllTabs(
            private = private,
            isConfirmed = false,
            isHomepageAsNewTabEnabled = settings.enableHomepageAsNewTab,
        )
    }

    override fun onCloseAllPrivateTabsWarningConfirmed(private: Boolean) {
        closeAllTabs(
            private = private,
            isConfirmed = true,
            isHomepageAsNewTabEnabled = settings.enableHomepageAsNewTab,
        )
    }

    override fun onRefreshAllTabsClicked() {
        val isPrivate = tabsTrayStore.state.selectedPage == Page.PrivateTabs
        val tabIds =
            if (isPrivate) {
                browserStore.state.privateTabs.map { it.id }
            } else {
                browserStore.state.normalTabs.map { it.id }
            }
        tabIds.forEach { tabId -> sessionUseCases.reload(tabId) }
        TabsTray.refreshedAllTabs.record(NoExtras())
    }

    override fun onReturnLockedTabsToRootClicked() {
        val isPrivate = tabsTrayStore.state.selectedPage == Page.PrivateTabs
        val tabs = if (isPrivate) browserStore.state.privateTabs else browserStore.state.normalTabs
        returnTabsToRoot(tabs.map { it.id })
    }

    override fun onReturnSelectedTabsToRootClicked() {
        returnTabsToRoot(tabsTrayStore.state.mode.selectedTabs.map { it.id })
        tabsTrayStore.dispatch(TabsTrayAction.ExitSelectMode)
    }

    override fun onAddTabToHomeScreenClicked(tab: TabsTrayItem.Tab) {
        if (!LockedTabShortcut.requestPin(context, tab)) {
            Toast.makeText(context, R.string.locked_tab_shortcut_not_supported, Toast.LENGTH_LONG).show()
        }
        tabsTrayStore.dispatch(TabsTrayAction.ExitSelectMode)
    }

    /**
     * Navigates each of the tabs with [tabIds] that is locked and has a root URL back to that URL. A tab that is already
     * showing its root URL is skipped so it keeps its scroll position and page state. This is a normal navigation, so
     * the page the tab was on stays in its history and the back button returns to it.
     */
    private fun returnTabsToRoot(tabIds: Collection<String>) {
        val state = tabsTrayStore.state
        tabIds.filter { it in state.lockedTabIds }.forEach { tabId ->
            val rootUrl = state.lockedTabRootUrls[tabId] ?: return@forEach
            if (browserStore.state.findTab(tabId)?.content?.url != rootUrl) {
                sessionUseCases.loadUrl(url = rootUrl, sessionId = tabId)
            }
        }
    }

    override fun onOpenRecentlyClosedClicked() {
        navController.navigate(TabManagementFragmentDirections.actionGlobalRecentlyClosed())
        Events.recentlyClosedTabsOpened.record(NoExtras())
    }

    override fun onPrivacyReportTapped() {
        TrackingProtection.privacyReportTapped.record(
            TrackingProtection.PrivacyReportTappedExtra(TABS_TRAY_TELEMETRY_SOURCE)
        )

        val currentSessionId = browserStore.state.selectedTabId
        navController.nav(
            R.id.tabManagementFragment,
            TabManagementFragmentDirections.actionTabManagementFragmentToGlobalProtectionsDashboard(
                customTabSessionId = currentSessionId
            ),
        )
    }

    /** Marks the inactive tabs auto close dialog as shown and to not be displayed again. */
    private fun markDialogAsShown() {
        settings.hasInactiveTabsAutoCloseDialogBeenDismissed = true
    }

    /**
     * Close all tabs.
     *
     * @param private Whether to close all of the Private tabs or all of the Normal tabs.
     * @param isConfirmed Whether the user has confirmed the warning message.
     * @param isHomepageAsNewTabEnabled Whether homepage as new tab is enabled.
     */
    private fun closeAllTabs(
        private: Boolean,
        isConfirmed: Boolean,
        isHomepageAsNewTabEnabled: Boolean,
    ) {
        val sessionsToClose =
            if (private) {
                ALL_PRIVATE_TABS
            } else {
                ALL_NORMAL_TABS
            }

        if (private && !isConfirmed) {
            val privateDownloads =
                browserStore.state.downloads.filter {
                    it.value.private && it.value.isActiveDownload()
                }
            if (privateDownloads.isNotEmpty()) {
                showCancelledDownloadWarning(privateDownloads.size, null, null)
                return
            }
        }

        handleRemoveAllTabs(
            isHomepageAsNewTabEnabled = isHomepageAsNewTabEnabled,
            sessionId = sessionsToClose,
        )
    }

    private fun handleRemoveAllTabs(
        isHomepageAsNewTabEnabled: Boolean,
        sessionId: String,
    ) {
        if (!isHomepageAsNewTabEnabled) {
            // NOTE: dismissTabManagerAndNavigateHome() queues the removal onto HomeScreenViewModel, executed by
            // TabsCleanupFeature when the home screen becomes visible. That feature enforces standalone tab locks
            // via its own TabManagerUiStateRepository instance (reading the same on-disk state), but does not
            // resolve tab-group membership, so a tab inside a locked group is not protected on this specific path.
            dismissTabManagerAndNavigateHome(sessionId)
            return
        }

        val tabsCount =
            when (sessionId) {
                ALL_NORMAL_TABS ->
                    tabsUseCases.removeAllUnlockedNormalTabs(
                        state = browserStore.state,
                        lockedTabIds = getLockedNormalTabIds(),
                    )
                ALL_ACTIVE_NORMAL_TABS ->
                    tabsUseCases.removeAllActiveUnlockedNormalTabs(
                        state = browserStore.state,
                        settings = settings,
                        lockedTabIds = getLockedNormalTabIds(),
                    )
                ALL_PRIVATE_TABS ->
                    tabsUseCases.removeAllUnlockedPrivateTabs(
                        state = browserStore.state,
                        lockedTabIds = getLockedPrivateTabIds(),
                    )
                else -> return
            }

        val isPrivate = sessionId == ALL_PRIVATE_TABS
        showUndoSnackbarForMultipleTabs(isPrivate, tabsCount)
    }
}
